// TypeScript Types for Código Fluente Studio

export interface Project {
  id: string;
  title: string;
  subtitle?: string;
  description: string;
  category: 'clipe' | 'personagem' | 'banda' | 'app' | 'experimento' | 'producao-musical' | 'educacao';
  tags: string[];
  thumbnail: string;
  videoUrl?: string;
  demoUrl?: string;
  githubUrl?: string;
  storeUrl?: string;  // Para lojas adicionais (Colab55, etc.)
  featured: boolean;
  date: string;
}

export interface Service {
  id: string;
  title: string;
  icon: string;
  description: string;
  whatsIncluded: string[];
  whoItsFor: string[];
  benefits: string[];
  category?: 'software' | 'ai' | 'audiovisual' | 'music-production' | 'live-performance' | 'digital-character' | 'visual-design';
  realExamples?: string[];
  detailedDescription?: string;
}

export interface Post {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  tags: string[];
  thumbnail: string;
}

export interface TimelineItem {
  year: string;
  title: string;
  description: string;
}

export interface SocialLink {
  name: string;
  url: string;
  icon: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  projectType: string;
  budgetRange: string;
  message: string;
}

export type ProjectCategory = 'todos' | 'clipe' | 'personagem' | 'banda' | 'app' | 'experimento' | 'producao-musical' | 'educacao';

// YouTube API Types
export interface YouTubeChannelData {
  channelId?: string;
  channelTitle: string;
  description?: string;
  thumbnail: string;
  subscriberCount: string | null;
  videoCount: string | null;
  viewCount?: string | null;
}

export interface YouTubeVideoData {
  videoId: string;
  title: string;
  description?: string;
  channelTitle: string;
  publishedAt: string;
  thumbnail: string;
  viewCount: string | null;
  likeCount?: string | null;
}

// Channel Type
export interface Channel {
  id: string;
  name: string;
  handle: string;
  url: string;
  description: string;
  thumbnail?: string; // URL da thumbnail do canal
  category: 'music' | 'tech' | 'character' | 'films' | 'label';
  status: 'active' | 'lab';
  featured: boolean;
}
