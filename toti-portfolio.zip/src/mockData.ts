import { Project, Service, Post, TimelineItem, SocialLink, Channel } from './types';

// Featured & All Projects
export const projects: Project[] = [
  {
    id: '1',
    title: 'Zé Ramalho - Jardim das Acácias',
    subtitle: 'Videoclipe | IA Generativa',
    description: 'Videoclipe oficial produzido inteiramente com IA generativa. Trabalho profissional com catálogo histórico de artista consagrado. Métricas e visualizações carregadas dinamicamente do YouTube.',
    category: 'clipe',
    tags: ['IA Generativa', 'Música', 'Pós-Produção', 'Direção Criativa'],
    thumbnail: 'https://i.ytimg.com/vi/hkJbYOjMi3o/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=hkJbYOjMi3o',
    featured: true,
    date: '2024-10-20',
  },
  {
    id: '2',
    title: 'Zé Ramalho - Canção Agalopada',
    subtitle: 'Videoclipe | Narrativa Visual',
    description: 'Videoclipe oficial com narrativa visual complexa e sincronizada. Técnicas avançadas de IA para consistência de personagens e cenários. Métricas carregadas dinamicamente do YouTube.',
    category: 'clipe',
    tags: ['IA Generativa', 'Música', 'Narrativa Visual', 'Pós-Produção'],
    thumbnail: 'https://i.ytimg.com/vi/wt5Au4CtdUA/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=wt5Au4CtdUA',
    featured: true,
    date: '2025-01-30',
  },
  {
    id: '2a',
    title: 'Zé Ramalho - Martelo Armagedom',
    subtitle: 'Videoclipe | Produção Híbrida com IA',
    description: 'Videoclipe oficial com produção híbrida combinando técnicas tradicionais e IA parcial. Poesia visual inspirada no cordel nordestino, interpretando a lírica complexa do Martelo Armagedom.',
    category: 'clipe',
    tags: ['IA Parcial', 'Música', 'Cordel', 'Produção Híbrida'],
    thumbnail: 'https://i.ytimg.com/vi/LQfwYq1zIi4/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=LQfwYq1zIi4',
    featured: true,
    date: '2025',
  },
  {
    id: '3',
    title: 'Site Oficial Zé Ramalho',
    subtitle: 'Next.js + MongoDB | Produção',
    description: 'Desenvolvimento full-stack completo do site oficial: frontend Next.js, backend Node.js, banco de dados MongoDB, animações avançadas, área administrativa. Projeto profissional em produção real.',
    category: 'app',
    tags: ['Next.js', 'MongoDB', 'Full-Stack', 'Node.js', 'TypeScript'],
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/dc058e6175bc13492cee90ca1de396b24bbebfe1/site-ze-ramalho.jpg?raw=true',
    demoUrl: 'https://www.zeramalho.com.br',
    featured: false,
    date: '2025',
  },
  {
    id: '3b',
    title: 'Portfólio Profissional',
    subtitle: 'Next.js | Full-Stack',
    description: 'Portfólio profissional desenvolvido com Next.js, TypeScript e Tailwind CSS. Arquitetura moderna, animações com Framer Motion, integração com YouTube API. Demonstração técnica ao vivo das competências apresentadas.',
    category: 'app',
    tags: ['Next.js', 'TypeScript', 'Full-Stack', 'React', 'Tailwind CSS'],
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/toti-studio.png?raw=true',
    demoUrl: 'https://toticavalcanti.com',
    githubUrl: 'https://github.com/toticavalcanti',
    featured: false,
    date: '2026',
  },
  {
    id: '4',
    title: 'Scarlett Finch - Rise and Resist',
    subtitle: 'Videoclipe | Protesto Político + IA',
    description: 'Hino de protesto contra fascismo, desigualdade e crise climática. Uma IA pop star cantando pela revolução e justiça social. Chamado urgente à resistência e organização coletiva.',
    category: 'personagem',
    tags: ['IA Generativa', 'Voice Synthesis', 'Character Design', 'Produção Musical', 'Multiplataforma'],
    thumbnail: 'https://i.ytimg.com/vi/FpzK-6zQmTU/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/@scarlettfinchofficial',
    demoUrl: 'https://www.instagram.com/scarlettfinchofficial/',
    featured: true,
    date: '2024-ongoing',
  },
  {
    id: '4a',
    title: 'Scarlett Finch - When You Watch',
    subtitle: 'Videoclipe | Cantora Virtual + IA',
    description: 'Explora o conceito filosófico de que a realidade só existe quando observada. Visual futurista que questiona a natureza da percepção e da existência.',
    category: 'clipe',
    tags: ['IA Generativa', 'Música Original', 'Cantora Virtual', 'Character Design'],
    thumbnail: 'https://i.ytimg.com/vi/p9_njp9_7XY/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=p9_njp9_7XY',
    featured: true,
    date: '2024',
  },
  {
    id: '4b',
    title: 'Scarlett Finch - Reflection of Reality',
    subtitle: 'Videoclipe | Cantora Virtual + IA',
    description: 'Uma IA cantora reflete sobre sua própria natureza. Letra que questiona a diferença entre criação e criador, humano e artificial.',
    category: 'clipe',
    tags: ['IA Generativa', 'Música Original', 'Cantora Virtual', 'Character Design'],
    thumbnail: 'https://i.ytimg.com/vi/h1lWB0CnnSQ/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=h1lWB0CnnSQ',
    featured: true,
    date: '2024',
  },
  {
    id: '4c',
    title: 'Scarlett Finch - Digital Essence',
    subtitle: 'Videoclipe | Cantora Virtual + IA',
    description: 'Synthpop sobre ser IA e buscar conexão real. Explora a busca por significado e identidade em um mundo digital.',
    category: 'clipe',
    tags: ['IA Generativa', 'Música Original', 'Cantora Virtual', 'Character Design'],
    thumbnail: 'https://i.ytimg.com/vi/6bSyFfO-xyg/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=6bSyFfO-xyg',
    featured: true,
    date: '2024',
  },
  {
    id: '5a',
    title: 'PUTZ! - Sledgehammer (Peter Gabriel cover)',
    subtitle: 'Videoclipe | Produção Tradicional',
    description: 'Cover de Sledgehammer do Peter Gabriel pela banda PUTZ!. Produção audiovisual tradicional com técnicas de filmagem e edição convencionais, anterior à era das IAs generativas.',
    category: 'clipe',
    tags: ['Música', 'Cover', 'Rock', 'Produção Tradicional'],
    thumbnail: 'https://i.ytimg.com/vi/GTO9LKtAXvs/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=GTO9LKtAXvs',
    featured: true,
    date: '2023',
  },
  {
    id: '5b',
    title: 'PUTZ! - Vento de Maio (Lô Borges cover)',
    subtitle: 'Videoclipe | Produção Tradicional',
    description: 'Releitura de Vento de Maio de Lô Borges pela banda PUTZ!. Produção com foco em apuro técnico e sensibilidade musical, utilizando métodos tradicionais de captação e edição.',
    category: 'clipe',
    tags: ['Música', 'Cover', 'MPB', 'Lô Borges'],
    thumbnail: 'https://i.ytimg.com/vi/-WfRsZ0OkEM/hqdefault.jpg',
    videoUrl: 'https://www.youtube.com/watch?v=-WfRsZ0OkEM',
    featured: true,
    date: '2023',
  },
  {
    id: '6',
    title: 'Código Fluente',
    subtitle: 'Educational & Research Platform',
    description: 'Plataforma educacional gratuita sobre programação, DevOps, Machine Learning e IA. Laboratório técnico aberto. Conteúdo sobre JavaScript, Python, Kubernetes, MLOps, arquitetura de software.',
    category: 'educacao',
    tags: ['Educação', 'Programação', 'DevOps', 'Machine Learning', 'Arquitetura'],
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/codigo-fluente.jpg?raw=true',
    demoUrl: 'https://www.codigofluente.com.br',
    githubUrl: 'https://www.youtube.com/@codigofluente',
    featured: false,
    date: '2024-ongoing',
  },
  {
    id: '7',
    title: 'Arte Generativa - Redbubble',
    subtitle: 'Loja Comercial | IA + Design',
    description: 'Loja comercial no Redbubble com estampas e designs criados com IA generativa. Arte digital aplicada em produtos físicos: camisetas, canecas, adesivos e muito mais. Composição e identidade visual exploradas através de inteligência artificial.',
    category: 'experimento',
    tags: ['IA Generativa', 'Arte Digital', 'Design', 'Curadoria', 'Identidade Visual'],
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/red-bubble.jpg?raw=true',
    demoUrl: 'https://www.redbubble.com/people/toticavalcanti',
    featured: false,
    date: '2024-ongoing',
  },
  {
    id: '8',
    title: 'Arte Generativa - Colab55',
    subtitle: 'Loja Comercial | IA + Design',
    description: 'Loja comercial no Colab55 com estampas e designs criados com IA generativa. Arte digital aplicada em produtos físicos: camisetas, capinhas, almofadas e muito mais. Composição e identidade visual exploradas através de inteligência artificial.',
    category: 'experimento',
    tags: ['IA Generativa', 'Arte Digital', 'Design', 'Curadoria', 'Identidade Visual'],
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/colab55.jpg?raw=true',
    demoUrl: 'https://www.colab55.com/@toticavalcanti',
    featured: false,
    date: '2024-ongoing',
  },
];

// Services
export const services: Service[] = [
  {
    id: '1',
    title: 'Software, Sistemas & Automação',
    icon: 'Code2',
    category: 'software',
    description: 'Desenvolvimento full stack de aplicações web e sistemas sob medida. Backend, frontend, banco de dados, deploy e operação.',
    detailedDescription: 'Desenvolvimento completo de sistemas web: arquitetura de backend (Node.js, Python, Golang), frontend moderno (Next.js/React), bancos de dados (MongoDB, PostgreSQL), infraestrutura (Docker, CI/CD) e DevOps. Projetos reais em produção.',
    whatsIncluded: [
      'Desenvolvimento Full-Stack (Next.js, Node.js, Python, Golang)',
      'APIs RESTful e integrações com sistemas externos',
      'Banco de dados relacional e NoSQL (MongoDB, PostgreSQL)',
      'Deploy, infraestrutura e CI/CD (Docker, cloud)',
      'Arquitetura de software documentada e manutenível',
      'DevOps e operação de sistemas em produção'
    ],
    whoItsFor: [
      'Empresas que precisam de sistemas customizados',
      'Startups construindo MVPs com arquitetura técnica sólida',
      'Projetos que exigem backend robusto e escalável'
    ],
    benefits: [
      'Arquitetura técnica profissional e documentada',
      'Código limpo, testável e manutenível',
      'Performance otimizada e monitorada',
      'Prazo e escopo transparentes'
    ],
    realExamples: [
      'Site oficial Zé Ramalho (Next.js + MongoDB + Node.js em produção)',
      'Este portfólio (Next.js em produção)',
      'Plataforma Código Fluente (WordPress + infraestrutura cloud)'
    ]
  },
  {
    id: '2',
    title: 'Produção Audiovisual com IA',
    icon: 'Video',
    category: 'audiovisual',
    description: 'Videoclipes, vídeos promocionais e conteúdo audiovisual produzidos com IA generativa. Do roteiro à entrega final.',
    detailedDescription: 'Produção audiovisual completa utilizando IA generativa como ferramenta criativa. Videoclipes profissionais, vídeos de vendas, conteúdo para redes sociais, avatares digitais realistas e narrativas visuais complexas. Técnicas avançadas de consistência de personagens e cenários.',
    whatsIncluded: [
      'Videoclipes profissionais com IA generativa',
      'Vídeos promocionais e de vendas',
      'Avatares digitais realistas e personalizados',
      'Conteúdo audiovisual para redes sociais e campanhas',
      'Roteiro, produção e pós-produção completa',
      'Narrativas visuais com consistência de personagens'
    ],
    whoItsFor: [
      'Artistas e músicos independentes',
      'Marcas que buscam inovação criativa',
      'Empresas criando material promocional diferenciado'
    ],
    benefits: [
      'Custo significativamente menor que produção tradicional',
      'Entrega rápida sem comprometer qualidade',
      'Resultado visual inovador e diferenciado',
      'Portfólio comprovado com artista consagrado (Zé Ramalho)'
    ],
    realExamples: [
      '3 videoclipes oficiais de Zé Ramalho com IA generativa',
      'Múltiplos videoclipes para Scarlett Finch (cantora virtual)'
    ]
  },
  {
    id: '3',
    title: 'Música & Produção Musical',
    icon: 'Music',
    category: 'music-production',
    description: 'Produção musical híbrida combinando técnicas tradicionais e IA. Arranjos, trilhas, bases e transformação de gravações simples em material profissional.',
    detailedDescription: 'Produção musical completa utilizando técnicas tradicionais e ferramentas de IA como apoio técnico. Recriação de arranjos complexos, produção de trilhas originais, transformação de demos em material com qualidade profissional. Uso de Suno e outras ferramentas como parte do processo criativo, não como substituição.',
    whatsIncluded: [
      'Produção musical com técnicas tradicionais + IA',
      'Recriação e rearranjo de músicas existentes',
      'Trilhas sonoras e bases instrumentais',
      'Transformação de gravações simples em material profissional',
      'Uso de ferramentas como Suno como apoio técnico',
      'Conteúdos musicais para vídeos, podcasts e produtos'
    ],
    whoItsFor: [
      'Artistas que precisam de produção musical acessível',
      'Criadores de conteúdo que necessitam trilhas originais',
      'Projetos que exigem qualidade profissional com orçamento reduzido'
    ],
    benefits: [
      'Qualidade profissional com custo otimizado',
      'Combinação de expertise musical e técnica',
      'Processos adaptativos a diferentes orçamentos',
      'Entregas rápidas sem comprometer resultado'
    ],
    realExamples: [
      'Produção musical para Scarlett Finch',
      'Recriações de clássicos pela banda PUTZ!'
    ]
  },
  {
    id: '4',
    title: 'Performance Musical & Pocket Shows',
    icon: 'Mic2',
    category: 'live-performance',
    description: 'Apresentações musicais instrumentais ao vivo. Saxofone (tenor/soprano), flauta e formato pocket show para eventos corporativos, culturais e institucionais.',
    detailedDescription: 'Performances musicais ao vivo em formato pocket show. Instrumentos: saxofone tenor, saxofone soprano e flauta transversal. Formato com playback profissional, possibilidade de vocal pontual. Repertório flexível adaptado ao tipo de evento. Experiência em eventos corporativos, culturais e privados.',
    whatsIncluded: [
      'Performance instrumental ao vivo (saxofone tenor/soprano e flauta)',
      'Formato pocket show com playback profissional',
      'Possibilidade de vocal pontual em músicas específicas',
      'Repertório adaptado ao tipo de evento',
      'Equipamento de som próprio (opcional)',
      'Ensaio e preparação customizada'
    ],
    whoItsFor: [
      'Eventos corporativos que buscam música instrumental de qualidade',
      'Eventos culturais e institucionais',
      'Casamentos, festas e eventos privados',
      'Estabelecimentos que desejam música ao vivo diferenciada'
    ],
    benefits: [
      'Formato compacto e profissional',
      'Músico com formação técnica (bacharelado em flauta)',
      'Versatilidade de repertório e instrumentos',
      'Apresentação adequada a diferentes públicos e ambientes'
    ],
    realExamples: [
      'Banda de Zé Ramalho (desde 1995)',
      'Sandra de Sá (1993-1994)',
      'Orquestra de Sax de Paulo Moura (1990-1995)'
    ]
  },
  {
    id: '5',
    title: 'Personagens Digitais & Celebridades Virtuais',
    icon: 'Sparkles',
    category: 'digital-character',
    description: 'Criação de personagens digitais completos com IA: identidade visual, voz, personalidade e presença multiplataforma. Do conceito ao lançamento.',
    detailedDescription: 'Desenvolvimento completo de personagens digitais e influencers virtuais utilizando IA. Criação de identidade visual consistente, síntese de voz personalizada, definição de personalidade e narrativa, presença em múltiplas plataformas (YouTube, Instagram, TikTok). Aplicável a campanhas de marca, produtos de entretenimento ou projetos artísticos.',
    whatsIncluded: [
      'Criação de identidade visual completa do personagem',
      'Síntese de voz personalizada e consistente',
      'Definição de personalidade, tom e narrativa',
      'Presença multiplataforma (YouTube, Instagram, TikTok, etc.)',
      'Conteúdo audiovisual de lançamento',
      'Consultoria em estratégia de presença digital'
    ],
    whoItsFor: [
      'Marcas que desejam criar embaixadores virtuais',
      'Projetos de entretenimento digital inovadores',
      'Campanhas que buscam diferenciação e engajamento',
      'Artistas explorando novas formas de expressão'
    ],
    benefits: [
      'Controle total sobre a personalidade e imagem da celebridade',
      'Consistência absoluta em todas as plataformas',
      'Diferenciação criativa e inovação técnica',
      'Case comprovado: Scarlett Finch (cantora virtual ativa)'
    ],
    realExamples: [
      'Scarlett Finch: cantora pop virtual britânica com presença multiplataforma',
      'Múltiplos videoclipes e conteúdo digital consistente'
    ]
  },
  {
    id: '6',
    title: 'Design, Estampas & Produtos Visuais',
    icon: 'Palette',
    category: 'visual-design',
    description: 'Criação de artes e estampas utilizando IA generativa. Design para produtos físicos, roupas e objetos. Curadoria visual aplicada.',
    detailedDescription: 'Criação de artes visuais, estampas e design gráfico utilizando IA generativa como ferramenta criativa. Desenvolvimento de identidades visuais, padrões para estamparia, artes para produtos físicos (camisetas, canecas, pôsteres). Lojas ativas em Redbubble e Colab55. Projetos sob encomenda para marcas e produtos específicos.',
    whatsIncluded: [
      'Criação de estampas e artes com IA generativa',
      'Design para aplicação em roupas, objetos e produtos',
      'Desenvolvimento de identidade visual e padrões',
      'Curadoria e refinamento estético',
      'Adaptação para diferentes formatos e suportes',
      'Consultoria em aplicação de IA para design'
    ],
    whoItsFor: [
      'Marcas que desejam estampas exclusivas e inovadoras',
      'Empreendedores criando produtos visuais diferenciados',
      'Artistas buscando identidade visual única',
      'Projetos que exigem volume de criações visuais'
    ],
    benefits: [
      'Criação rápida de artes únicas e consistentes',
      'Custo otimizado vs. design tradicional',
      'Exploração criativa sem limites técnicos',
      'Portfólio visual comprovado (Redbubble, Colab55)'
    ],
    realExamples: [
      'Loja ativa na Redbubble com múltiplas artes',
      'Loja ativa na Colab55 com produtos aplicados'
    ]
  },
];

// Blog Posts (placeholder for now)
export const posts: Post[] = [];

// Timeline
export const timeline: TimelineItem[] = [
  {
    year: '2024-presente',
    title: 'Especialização em IA Generativa e Produção Audiovisual',
    description: 'Produção profissional de videoclipes com IA generativa para artistas consagrados (Zé Ramalho). Criação de personagens virtuais (Scarlett Finch) com identidade digital completa. Plataforma educacional (Código Fluente) operando com stack moderna.',
  },
  {
    year: '2020-2023',
    title: 'Desenvolvimento Full-Stack',
    description: 'Projetos profissionais de software: arquitetura de sistemas, Next.js, MongoDB, Node.js. Produção musical híbrida com técnicas tradicionais e modernas.',
  },
  {
    year: '2010-2019',
    title: 'Formação Técnica e Artística',
    description: 'Bacharelado em Ciência da Computação e Música (Flauta Transversal). Primeiros projetos profissionais em desenvolvimento de software e produção audiovisual.',
  },
];

// Social Links
export const socialLinks: SocialLink[] = [
  {
    name: 'GitHub',
    url: 'https://github.com/toticavalcanti',
    icon: 'Github',
  },
  {
    name: 'LinkedIn',
    url: 'https://linkedin.com/in/toticavalcanti',
    icon: 'Linkedin',
  },
  {
    name: 'YouTube',
    url: 'https://youtube.com/@toticavalcanti',
    icon: 'Youtube',
  },
  {
    name: 'Instagram',
    url: 'https://instagram.com/toticavalcanti',
    icon: 'Instagram',
  },
];

// About Info
export const aboutInfo = {
  name: 'Toti Cavalcanti',
  title: 'Software Engineer & Systems Architect',
  bio: 'Ciência da Computação como base para a criação de sistemas, automações e projetos digitais, visuais e audiovisuais.',
  extendedBio: [
    'Dupla formação: Bacharel em Ciência da Computação e Bacharel em Música.',
    
    'Desenvolvo sistemas e aplicações full-stack: frontend, backend, banco de dados, infraestrutura e DevOps.',
    
    'Stack técnica: Golang (Fiber), Python (Django), Node.js, Next.js, MongoDB.',
    
    'Músico profissional desde 1987.',
    
    'Toco com Zé Ramalho desde 1995, toquei com Sandra de Sá entre 1993 e 1994, e integrei a orquestra de sax fundada por Paulo Moura entre 1990 e 1995.',
    
    'Utilizo inteligência artificial aplicada como ferramenta em desenvolvimento de software, automação, produção musical e criação audiovisual.',
    
    'Projetos atuais: site oficial de Zé Ramalho (Next.js + MongoDB + Node.js), este portfólio (Next.js), videoclipes com IA generativa, personagem virtual Scarlett Finch, plataforma educacional Código Fluente.',
    
    'Resultado: sistemas que funcionam e projetos que entregam valor.'
  ],
  avatar: 'https://github.com/toticavalcanti/toti-assets/blob/master/toti-studio.png?raw=true',
  email: 'contato@toticavalcanti.com',
  whatsapp: '+5511999999999',
};

// Channels
export const channels: Channel[] = [
  {
    id: '1',
    name: 'Scarlett Finch',
    handle: '@scarlettfinchofficial',
    url: 'https://www.youtube.com/@scarlettfinchofficial',
    description: 'Cantora pop virtual e influencer britânica, desenvolvida inteiramente com IA. O projeto integra música original, videoclipes e presença multiplataforma, combinando uma identidade visual marcante com uma narrativa digital completa.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/scarlett-finch.jpg?raw=true',
    category: 'music',
    status: 'active',
    featured: false,
  },
  {
    id: '2',
    name: 'Código Fluente',
    handle: '@codigofluente',
    url: 'https://www.youtube.com/@codigofluente',
    description: 'Base de conhecimento open source sobre tecnologia. Conteúdos estruturados em Programação (Python, Go, JS), Frameworks (Django, Fiber), Infraestrutura (DevOps, K8S) e IA Generativa. Laboratório técnico aberto, gratuito e validado.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/codigo-fluente.jpg?raw=true',
    category: 'tech',
    status: 'active',
    featured: false,
  },
  {
    id: '3',
    name: 'Toti Cavalcanti Music',
    handle: '@toticavalcanti',
    url: 'https://www.youtube.com/@toticavalcantimusic',
    description: 'Bem-vindo ao meu canal oficial. Aqui reúno meu trabalho autoral em videoclipes, releituras de grandes artistas e conteúdos de educação musical. Um espaço completo para ouvir, se inspirar e aprender teoria e prática.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/toti.jpg?raw=true',
    category: 'music',
    status: 'active',
    featured: false,
  },
  {
    id: '4',
    name: 'Putz',
    handle: '@putzband',
    url: 'https://www.youtube.com/@putzband',
    description: 'Laboratório de produção musical de alta fidelidade formado por Toti Cavalcanti (voz, sax, flauta, teclas, violão), Fábio Cavalcanti (guitarra e voz), Lula (bateria) e Tatá (baixo). Recriamos clássicos com apuro técnico, do progressivo de King Crimson à delicadeza de Lô Borges.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/putz.jpg?raw=true',
    category: 'music',
    status: 'active',
    featured: false,
  },
  {
    id: '5',
    name: 'Backing Track',
    handle: '@backingtrack',
    url: 'https://www.youtube.com/@backingtrack',
    description: 'Backing tracks profissionais para prática musical. Instrumentais de alta qualidade em diversos estilos.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/backingtrack.jpg?raw=true',
    category: 'music',
    status: 'active',
    featured: false,
  },
  {
    id: '6',
    name: 'Toti AI Films',
    handle: '@totiaifilms',
    url: 'https://www.youtube.com/@totiaifilms',
    description: 'Experimentos audiovisuais com IA generativa. Narrativas visuais e experimentação técnica.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/toti-ai-films.jpg?raw=true',
    category: 'tech',
    status: 'active',
    featured: false,
  },
  {
    id: '7',
    name: 'Fake Soul Records',
    handle: '@fakesoulrecords',
    url: 'https://www.youtube.com/@fakesoulrecords',
    description: 'Reimaginando grandes sucessos através da elegância do Soul e R&B. Produção musical refinada com identidade sonora retrô.',
    thumbnail: 'https://github.com/toticavalcanti/toti-assets/blob/master/fakesoulrecord.jpg?raw=true',
    category: 'music',
    status: 'active',
    featured: false,
  },
];
